package hrs.common.Exception.PromotionService;

public class EnterpriseNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
