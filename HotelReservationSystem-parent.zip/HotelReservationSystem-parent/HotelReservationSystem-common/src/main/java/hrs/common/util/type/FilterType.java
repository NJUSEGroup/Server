package hrs.common.util.type;

public enum FilterType {
	Name,Star,Score,IfOrdered,RoomType;
}
