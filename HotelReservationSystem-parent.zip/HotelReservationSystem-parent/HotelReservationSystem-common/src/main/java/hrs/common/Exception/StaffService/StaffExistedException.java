package hrs.common.Exception.StaffService;

public class StaffExistedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
