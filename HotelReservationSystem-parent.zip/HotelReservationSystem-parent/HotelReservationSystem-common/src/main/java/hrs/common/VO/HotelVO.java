package hrs.common.VO;

import java.io.Serializable;
import java.util.List;

import hrs.common.POJO.CommercialCirclePO;
import hrs.common.POJO.HotelPO;
import hrs.common.POJO.LocationPO;
import hrs.common.POJO.StaffPO;
import hrs.common.util.type.OrderStatus;

public class HotelVO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int id;
	public String name;
	public int star;
	public double score;
	public LocationVO location;
	public CommercialCircleVO commercialCircle;
	public String profile;
	public String service;
	public  StaffVO staff;
	public String street;
	public List<OrderStatus> status;
	public HotelVO() {
		// TODO Auto-generated constructor stub
	}
	public HotelVO(HotelPO po,StaffVO staff){
		this.id = po.getId();
		this.name = po.getName();
		this.star = po.getStar();
		this.score = po.getScore();
		this.location =  (po.getLocation() != null) ? new LocationVO(po.getLocation()):null;
		this.commercialCircle = (po.getCommercialCircle() != null) ? new CommercialCircleVO(po.getCommercialCircle()):null;
		this.profile = po.getProfile();
		this.staff = staff;
		this.service = po.getService();
		this.street = po.getStreet();
	}
	
	public HotelVO(HotelPO po){
		this.id = po.getId();
		this.name = po.getName();
		this.star = po.getStar();
		this.score = po.getScore();
		this.location = po.getLocation() != null? new LocationVO(po.getLocation()):null;
		this.commercialCircle = po.getCommercialCircle() != null? new CommercialCircleVO(po.getCommercialCircle()):null;
		this.staff = po.getStaff() != null ? new StaffVO(po.getStaff()):null;
		this.profile = po.getProfile();
		this.service = po.getService();
		this.street = po.getStreet();
	}
	
	public HotelVO(int id, String name, int star, double score, LocationVO location,
			CommercialCircleVO commercialCircle, String profile, String service, String street) {
		super();
		this.id = id;
		this.name = name;
		this.star = star;
		this.score = score;
		this.location = location;
		this.commercialCircle = commercialCircle;
		this.profile = profile;
		this.service = service;
		this.street = street;
	}

	

	public HotelVO(int id, String name, int star, double score, String profile, String service) {
		super();
		this.id = id;
		this.name = name;
		this.star = star;
		this.score = score;
		this.profile = profile;
		this.service = service;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((commercialCircle == null) ? 0 : commercialCircle.hashCode());
		result = prime * result + id;
		result = prime * result + ((location == null) ? 0 : location.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((profile == null) ? 0 : profile.hashCode());
		long temp;
		temp = Double.doubleToLongBits(score);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((service == null) ? 0 : service.hashCode());
		result = prime * result + star;
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((street == null) ? 0 : street.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HotelVO other = (HotelVO) obj;
		if (commercialCircle == null) {
			if (other.commercialCircle != null)
				return false;
		} else if (!commercialCircle.equals(other.commercialCircle))
			return false;
		if (id != other.id)
			return false;
		if (location == null) {
			if (other.location != null)
				return false;
		} else if (!location.equals(other.location))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (profile == null) {
			if (other.profile != null)
				return false;
		} else if (!profile.equals(other.profile))
			return false;
		if (Double.doubleToLongBits(score) != Double.doubleToLongBits(other.score))
			return false;
		if (service == null) {
			if (other.service != null)
				return false;
		} else if (!service.equals(other.service))
			return false;
		if (star != other.star)
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (street == null) {
			if (other.street != null)
				return false;
		} else if (!street.equals(other.street))
			return false;
		return true;
	}
	
}
