package hrs.common.Exception.UserService;

public class UserPasswordErrorException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
