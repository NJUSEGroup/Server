package hrs.common.Exception.CreditRecordService;

public class CreditRecordNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
