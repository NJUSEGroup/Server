package hrs.common.Exception.OfflineRecordService;

public class OfflineRecordNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
