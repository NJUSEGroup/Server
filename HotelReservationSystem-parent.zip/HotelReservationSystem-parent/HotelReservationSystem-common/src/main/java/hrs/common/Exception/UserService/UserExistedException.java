package hrs.common.Exception.UserService;

public class UserExistedException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
