package hrs.common.Exception.Promotion.HotelDiscountService;

public class HotelDiscountNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
