package hrs.common.util.type;

public enum OrderRule {
	Star,Score,Value;
}
