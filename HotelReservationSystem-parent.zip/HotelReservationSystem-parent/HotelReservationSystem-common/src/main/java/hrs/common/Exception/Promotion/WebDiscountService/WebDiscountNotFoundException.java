package hrs.common.Exception.Promotion.WebDiscountService;

public class WebDiscountNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
