package hrs.common.Exception.StaffService;

public class StaffNotFoundExceptioon extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
