package hrs.server;

import hrs.server.Initial.NetInitial;
/**
 * 服务器启动器
 * @author NewSong
 *
 */
public class Launcher {
	public static void main(String[] args) {
		NetInitial.init();
	}
}
