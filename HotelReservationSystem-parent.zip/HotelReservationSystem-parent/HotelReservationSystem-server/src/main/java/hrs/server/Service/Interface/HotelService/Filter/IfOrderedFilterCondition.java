package hrs.server.Service.Interface.HotelService.Filter;

import hrs.common.Controller.UserController.FilterCondition;
import hrs.common.util.type.FilterType;

public class IfOrderedFilterCondition extends FilterCondition {
	
	public IfOrderedFilterCondition(FilterType type) {
		super(type);
		// TODO Auto-generated constructor stub
	}

}
