package hrs.server.Service.Impl.PromotionService.WebDiscountService;

import hrs.common.VO.OrderVO;

public class VIPWebDiscount extends WebDiscount{

	@Override
	public OrderVO discount(OrderVO order) {
		// TODO Auto-generated method stub
		return null;
	}

}
