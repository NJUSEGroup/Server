package hrs.server.Service.Impl.PromotionService.WebDiscountService;

import hrs.common.VO.OrderVO;

public class SpecialPeriodWebDiscount extends WebDiscount{

	@Override
	public OrderVO discount(OrderVO order) {
		return null;
	}

}
